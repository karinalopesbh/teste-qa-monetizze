require 'capybara'
require 'capybara/cucumber'
require 'report_builder'
require 'selenium-webdriver'

Capybara.register_driver :selenium_chrome do |app|
  Capybara::Selenium::Driver.new(
    app,
    browser: :chrome,
    desired_capabilities: { accept_insecure_certs: false }

  )
end


Capybara.configure do |config|
    config.default_driver = :selenium_chrome #roda no navegador
	Selenium::WebDriver::Chrome.driver_path = "C:\\teste-qa-monetizze\\Cucumber\\chromedriver.exe"

end


