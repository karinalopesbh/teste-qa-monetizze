Dado("O site de vinhos") do
  visit 'http://monetizzetesteqa.s3-website-us-east-1.amazonaws.com/'
end

Quando("Clicar na funcionalidade Loja") do
click_link 'Loja' 
end

Então("Todos os vinhos cadastrados devem ser listados") do
  page.has_content?("Nossos Produtos")
end

Dado("A tela com a listagem de todos os vinhos cadastrados") do
  visit 'http://monetizzetesteqa.s3-website-us-east-1.amazonaws.com/'
  click_link 'Loja' 
  page.has_content?("Nossos Produtos")
end	

Quando("Clicar em um vinho") do
  click_link 'Trius Cabernet France 2011' 
end

Então("Deve ser exibida tela com os detalhes do vinho clicado") do
  page.has_content?("Trius Cabernet France 2011")
end
